The following files were generated for 'partition_divider' in directory 
/afs/athena.mit.edu/user/t/u/tuanphan/Desktop/6.111/Final Project/Space_Invader:

partition_divider.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

partition_divider.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

partition_divider.sym:
   Please see the core data sheet.

partition_divider.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

partition_divider.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

partition_divider.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

partition_divider.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

partition_divider.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

partition_divider_div_gen_v2_0_xst_1.ngc_xst.xrpt:
   Please see the core data sheet.

partition_divider_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

partition_divider_readme.txt:
   Text file indicating the files generated and how they are used.

partition_divider_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

